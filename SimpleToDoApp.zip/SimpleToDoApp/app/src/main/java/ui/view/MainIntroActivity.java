package ui.view;

import android.app.Activity;

public class MainIntroActivity extends Activity {
}
