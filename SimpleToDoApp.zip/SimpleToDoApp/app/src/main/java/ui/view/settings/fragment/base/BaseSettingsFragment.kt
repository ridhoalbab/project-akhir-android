package com.example.simple_to_do_app.ui.view.settings.fragment.base

import androidx.fragment.app.Fragment
import com.example.simple_to_do_app.R
import com.example.simple_to_do_app.ui.view.settings.activity.SettingsActivity

abstract class BaseSettingsFragment : Fragment() {

    fun setTitle(title: String) {
        (activity as SettingsActivity).setToolbarTitle(title)
    }

    override fun onDetach() {
        super.onDetach()
        setTitle(getString(R.string.settings))
    }
}