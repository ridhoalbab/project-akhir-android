package com.example.simple_to_do_app.vm

import android.app.Application
import com.example.simple_to_do_app.data.models.Task
import com.example.simple_to_do_app.vm.base.BaseViewModel

class AddTaskViewModel(app: Application) : BaseViewModel(app) {
    fun saveTask(task: Task) = repository.saveTask(task)
}