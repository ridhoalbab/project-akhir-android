package com.example.simple_to_do_app.vm

import android.app.Application
import com.example.simple_to_do_app.data.models.Task
import com.example.simple_to_do_app.vm.base.BaseViewModel

class DeleteTaskViewModel(app: Application) : BaseViewModel(app) {
    fun deleteTask(task: Task) = repository.deleteTask(task)
}