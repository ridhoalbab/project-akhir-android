package com.example.simple_to_do_app.vm

import android.app.Application
import com.example.simple_to_do_app.data.models.Task
import com.example.simple_to_do_app.vm.base.BaseViewModel

class EditTaskViewModel(app: Application) : BaseViewModel(app) {
    fun updateTask(task: Task) = repository.updateTask(task)
}