package com.example.simple_to_do_app.vm

import android.app.Application
import com.example.simple_to_do_app.data.models.Task
import com.example.simple_to_do_app.vm.base.BaseViewModel

class TaskListViewModel(app: Application) : BaseViewModel(app) {
    val liveData = repository.getAllTasksLiveData()

    fun updateTaskOrder(tasks: List<Task>) = repository.updateTaskOrder(tasks)

    fun deleteTask(task: Task) = repository.deleteTask(task)

    fun saveTask(task: Task) = repository.saveTask(task)
}