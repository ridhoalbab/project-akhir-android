package com.example.simple_to_do_app.vm.base

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.simple_to_do_app.data.database.TaskListRepository

abstract class BaseViewModel(app: Application) : AndroidViewModel(app) {
    val repository = TaskListRepository(app)
}